
with open('text.txt', 'r') as file:
    lines = file.readlines()


pos1 = 1
pos2 = 2
lines[pos1 - 1], lines[pos2 - 1] = lines[pos2 - 1], lines[pos1 - 1]


with open('text.txt', 'w') as file:
    file.writelines(lines)


