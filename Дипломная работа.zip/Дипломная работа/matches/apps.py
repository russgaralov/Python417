from django.apps import AppConfig

class MatchesConfig(AppConfig):
    name = 'matches'
    verbose_name = 'Матчи'
