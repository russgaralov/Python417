from django.contrib import admin
from .models import Match

@admin.register(Match)
class MatchAdmin(admin.ModelAdmin):
    list_display = ('home', 'away', 'date', 'tournament', 'result')
    list_filter = ('tournament', 'date')
    search_fields = ('home__name', 'away__name')
