from django.db import models
from teams.models import Team

class Match(models.Model):
    home = models.ForeignKey(Team, on_delete=models.CASCADE, related_name='home_matches')
    away = models.ForeignKey(Team, on_delete=models.CASCADE, related_name='away_matches')
    date = models.DateTimeField()
    tournament = models.CharField(max_length=120, blank=True)
    result = models.CharField(max_length=20, blank=True, null=True)  # например, "2:1"

    class Meta:
        verbose_name = 'Матч'
        verbose_name_plural = 'Матчи'
        ordering = ['-date']

    def __str__(self):
        return f"{self.home} vs {self.away}"
