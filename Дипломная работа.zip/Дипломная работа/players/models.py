from django.db import models
from teams.models import Team

POSITIONS = [
    ('GK', 'Вратарь'),
    ('DF', 'Защитник'),
    ('MF', 'Полузащитник'),
    ('FW', 'Нападающий'),
]

class Player(models.Model):
    name = models.CharField(max_length=120)
    position = models.CharField(max_length=2, choices=POSITIONS)
    team = models.ForeignKey(Team, on_delete=models.SET_NULL, null=True, related_name='players')
    number = models.PositiveIntegerField(default=0)
    photo = models.ImageField(upload_to='players/', blank=True, null=True)
    goals = models.PositiveIntegerField(default=0)
    assists = models.PositiveIntegerField(default=0)

    class Meta:
        verbose_name = 'Игрок'
        verbose_name_plural = 'Игроки'
        ordering = ['name']

    def __str__(self):
        return f"{self.name} ({self.get_position_display()})"
