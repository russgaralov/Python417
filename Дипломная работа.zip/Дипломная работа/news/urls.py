from django.urls import path
from . import views

app_name = 'news'
urlpatterns = [
    path('', views.NewsListView.as_view(), name='list'),
    path('create/', views.NewsCreateView.as_view(), name='create'),
    path('<slug:slug>/', views.NewsDetailView.as_view(), name='detail'),
    path('<slug:slug>/edit/', views.NewsUpdateView.as_view(), name='edit'),
    path('<slug:slug>/delete/', views.NewsDeleteView.as_view(), name='delete'),
    path('category/<slug:slug>/', views.CategoryListView.as_view(), name='by_category'),
    path('tag/<slug:slug>/', views.TagListView.as_view(), name='by_tag'),
]
