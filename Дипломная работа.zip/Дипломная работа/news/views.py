from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin
from django.urls import reverse_lazy
from django.views.generic import ListView, DetailView, CreateView, UpdateView, DeleteView
from .models import News, Category, Tag
from .forms import NewsForm

class NewsListView(ListView):
    model = News
    paginate_by = 10
    template_name = 'news/list.html'
    context_object_name = 'items'

class NewsDetailView(DetailView):
    model = News
    template_name = 'news/detail.html'
    context_object_name = 'item'

class AuthorOrStaffRequired(UserPassesTestMixin):
    def test_func(self):
        obj = self.get_object()
        u = self.request.user
        return u.is_staff or (obj.author_id == getattr(u, 'id', None))

class NewsCreateView(LoginRequiredMixin, CreateView):
    model = News
    form_class = NewsForm
    template_name = 'news/form.html'

    def form_valid(self, form):
        form.instance.author = self.request.user
        return super().form_valid(form)

class NewsUpdateView(LoginRequiredMixin, AuthorOrStaffRequired, UpdateView):
    model = News
    form_class = NewsForm
    template_name = 'news/form.html'

class NewsDeleteView(LoginRequiredMixin, AuthorOrStaffRequired, DeleteView):
    model = News
    success_url = reverse_lazy('news:list')
    template_name = 'news/confirm_delete.html'

class CategoryListView(ListView):
    template_name = 'news/by_category.html'
    context_object_name = 'items'

    def get_queryset(self):
        self.category = Category.objects.get(slug=self.kwargs['slug'])
        return News.objects.filter(category=self.category)

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        ctx['category'] = self.category
        return ctx

class TagListView(ListView):
    template_name = 'news/by_tag.html'
    context_object_name = 'items'

    def get_queryset(self):
        self.tag = Tag.objects.get(slug=self.kwargs['slug'])
        return News.objects.filter(tags=self.tag)

    def get_context_data(self, **kwargs):
        ctx = super().get_context_data(**kwargs)
        ctx['tag'] = self.tag
        return ctx
