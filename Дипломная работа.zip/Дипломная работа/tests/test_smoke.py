from django.test import TestCase
from django.urls import reverse
from django.contrib.auth.models import User
from news.models import Category, News

class SmokeTests(TestCase):
    def setUp(self):
        self.user = User.objects.create_user('john','john@example.com','pass')
        self.cat = Category.objects.create(name='Общее', slug='general')

    def test_home(self):
        r = self.client.get(reverse('core:home'))
        self.assertEqual(r.status_code, 200)

    def test_create_news(self):
        self.client.login(username='john', password='pass')
        r = self.client.post(reverse('news:create'), {
            'title': 'Test title',
            'slug': 'test-title',
            'content': 'Test content',
            'category': self.cat.id
        })
        self.assertEqual(r.status_code, 302)
        self.assertEqual(News.objects.count(), 1)
