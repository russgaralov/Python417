from django.shortcuts import render
from news.models import News

def home(request):
    latest = News.objects.select_related('category', 'author').order_by('-created_at')[:10]
    return render(request, 'core/home.html', {'latest': latest})

def about(request):
    return render(request, 'core/about.html')

def contacts(request):
    return render(request, 'core/contacts.html')
