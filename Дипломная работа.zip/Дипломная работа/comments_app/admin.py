from django.contrib import admin
from .models import Comment

@admin.register(Comment)
class CommentAdmin(admin.ModelAdmin):
    list_display = ('news', 'user', 'created_at', 'is_moderated')
    list_filter = ('is_moderated', 'created_at')
    search_fields = ('text',)
