from django.urls import path
from . import views

app_name = 'comments_app'
urlpatterns = [
    path('add/<slug:slug>/', views.add_comment, name='add'),
]
