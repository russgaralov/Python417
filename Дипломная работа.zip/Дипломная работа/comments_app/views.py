from django.contrib.auth.decorators import login_required
from django.shortcuts import redirect, get_object_or_404
from news.models import News
from .forms import CommentForm

@login_required
def add_comment(request, slug):
    news = get_object_or_404(News, slug=slug)
    if request.method == 'POST':
        form = CommentForm(request.POST)
        if form.is_valid():
            c = form.save(commit=False)
            c.user = request.user
            c.news = news
            c.save()
    return redirect('news:detail', slug=slug)
