from django.apps import AppConfig

class CommentsAppConfig(AppConfig):
    name = 'comments_app'
    verbose_name = 'Комментарии'
