from django.db import models

class Team(models.Model):
    name = models.CharField(max_length=120, unique=True)
    city = models.CharField(max_length=120, blank=True)
    logo = models.ImageField(upload_to='teams/', blank=True, null=True)
    description = models.TextField(blank=True)

    class Meta:
        verbose_name = 'Команда'
        verbose_name_plural = 'Команды'
        ordering = ['name']

    def __str__(self):
        return self.name
