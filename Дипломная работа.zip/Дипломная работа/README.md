# Football News Site (Django + SQL)

Учебный проект: новостной сайт о футболе на Django.
Содержит приложения: core, news, comments_app, users_app, teams, players, matches.

## Быстрый старт (локально)

```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt

# Инициализация базы и запуск
python manage.py migrate
python manage.py createsuperuser
python manage.py loaddata fixtures/initial.json  # опционально, пример данных
python manage.py runserver
```

Открой: http://127.0.0.1:8000

## База данных
По умолчанию SQLite для простоты. Для PostgreSQL настрой переменные окружения в `.env`:
```
DB_ENGINE=django.db.backends.postgresql
DB_NAME=football
DB_USER=postgres
DB_PASSWORD=postgres
DB_HOST=127.0.0.1
DB_PORT=5432
```

## Приложения
- `core` — базовые страницы, шаблоны, навигация
- `news` — новости, категории, теги
- `comments_app` — комментарии к новостям
- `users_app` — регистрация/логин, профиль
- `teams` — команды/клубы
- `players` — игроки
- `matches` — календарь и результаты

## Команды разработки
```bash
python manage.py test
python manage.py collectstatic
```

## Docker (опционально)
```bash
docker build -t football-news .
docker run -p 8000:8000 football-news
```
