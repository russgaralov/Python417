
password = 'my-p@ssW0rd'


if len(password) < 6 or len(password) > 18:
    print("Пароль не соответствует требованиям по длине.")
else:

    has_digit = any(char.isdigit() for char in password)
    if not has_digit:
        print("Пароль должен содержать хотя бы одну цифру.")
    else:

        has_letter = any(char.isalpha() for char in password)
        if not has_letter:
            print("Пароль должен содержать хотя бы одну букву английского алфавита.")
        else:

            has_special = any(char in ['-', '@', '_'] for char in password)
            if not has_special:
                print("Пароль должен содержать хотя бы один из символов: дефис, собака или подчеркивание.")
            else:
                print("Пароль соответствует всем требованиям.")
